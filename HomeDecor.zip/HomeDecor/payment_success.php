<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Payment Successful</title>
</head>
<body>
    <div style="text-align: center; margin-top: 50px;">
        <h2 style="color: green;">Payment Successful!</h2>
        <p>Thank you for your purchase.</p>
        <a href="index.php">Return to Home</a>
    </div>
</body>
</html>